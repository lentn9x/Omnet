#ifndef GEONODE_H_
#define GEONODE_H_
#define MIXIM_INET
#include <math.h>
#include <algorithm>

class GeoNode {
public:

    long nodeID;
    double locationX, locationY;

    GeoNode();
    GeoNode(double a, double b);
    GeoNode(long x, double a, double b);
    bool operator==(const GeoNode& b);
    bool operator!=(const GeoNode& b);
    double distance(GeoNode a);
    void drawLine(GeoNode a, double baseLineFactor[]);
    double distanceToLine(double baseLineFactor[]);
};

#endif /* GeoNode_H_ */
